/**
 * Apps Script nhận xác nhận từ thiệp mời
 * và ghi vào Google Sheet:
 * https://docs.google.com/spreadsheets/d/1nOfNEZ5rpobmq45SyO7siYwudHcDVxaHQ4Ak0gMZvbk
 *
 * Cách gắn:
 * 1. Mở đúng file Google Sheet ở trên (đúng tài khoản Google của bạn).
 * 2. Extensions / Tiện ích mở rộng → Apps Script.
 * 3. Xóa code mặc định, dán toàn bộ file này, bấm Save.
 * 4. Deploy → New deployment → Web app
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 5. Copy URL kết thúc bằng /exec, dán vào CONFIG.linkNhanXacNhan trong index.html
 */

var SHEET_ID = "1nOfNEZ5rpobmq45SyO7siYwudHcDVxaHQ4Ak0gMZvbk";
var SHEET_NAME = ""; // để trống = lấy sheet đầu tiên

function sheet_() {
  var ss = SpreadsheetApp.openById(SHEET_ID);
  return SHEET_NAME ? ss.getSheetByName(SHEET_NAME) : ss.getSheets()[0];
}

function damBaoTieuDe_(sh) {
  if (sh.getLastRow() === 0) {
    sh.appendRow(["Thời gian", "Tên", "Lựa chọn", "Lời chúc"]);
    sh.getRange(1, 1, 1, 4).setFontWeight("bold");
    sh.setFrozenRows(1);
  }
}

function doPost(e) {
  var p = (e && e.parameter) ? e.parameter : {};
  var sh = sheet_();
  damBaoTieuDe_(sh);
  sh.appendRow([
    p.luc || Utilities.formatDate(new Date(), "Asia/Ho_Chi_Minh", "dd/MM/yyyy HH:mm:ss"),
    p.ten || "",
    p.traLoi || "",
    p.loiChuc || ""
  ]);
  return ContentService
    .createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService.createTextOutput("Thiep moi Truong The Bach: script dang chay.");
}
