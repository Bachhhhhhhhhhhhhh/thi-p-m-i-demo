# Thiệp mời lễ tốt nghiệp — Trương Thế Bách

Trang giống mẫu GitHub Pages, đã đổi tên và số điện thoại.
Câu trả lời khách gửi sẽ vào Sheet:

https://docs.google.com/spreadsheets/d/1nOfNEZ5rpobmq45SyO7siYwudHcDVxaHQ4Ak0gMZvbk

Số điện thoại / Zalo trên thiệp: **0372362558**

## 1. Sửa nội dung thiệp

Mở `index.html`, chỉ sửa khối `const CONFIG = { ... }`:

- `ten` — đã là Trương Thế Bách
- `batDau`, `ngayGioChu` — giờ và ngày lễ (đang để mẫu 15/11/2026, nhớ sửa)
- `diaDiem`, `diaChi`, `linkBanDo`
- `loiNhan` — lời nhắn
- `anh` — để `"anh.jpg"` nếu đặt thêm ảnh cạnh file này
- `nhanTraLoi` — các nút khách chọn
- `soDienThoai` — đã là 0372362558

Xem trước: mở `index.html` bằng trình duyệt.

## 2. Nối Google Sheet (bắt buộc nếu muốn xem data trong bảng)

GitHub Pages / file HTML tĩnh **không tự ghi** được vào Sheet.
Phải có Apps Script đứng giữa.

1. Mở đúng Sheet bằng tài khoản Google của bạn.
2. Menu **Tiện ích mở rộng → Apps Script**.
3. Xóa code mặc định, dán toàn bộ `Code.gs`, bấm Save (Ctrl+S).
4. **Deploy → New deployment**.
5. Hình bánh răng / loại: **Web app**.
6. Execute as: **Me**.
7. Who has access: **Anyone** (không thì khách gửi sẽ bị chặn).
8. Deploy, cho phép quyền truy cập Sheet lần đầu.
9. Copy URL dạng:

   `https://script.google.com/macros/s/AKfycb...../exec`

10. Dán URL đó vào `index.html`:

```js
linkNhanXacNhan: "https://script.google.com/macros/s/AKfycb...../exec",
```

11. Lưu file, tải lại trang, tự gửi thử 1 dòng.
12. Mở lại Sheet — sẽ có cột:

    Thời gian | Tên | Lựa chọn | Lời chúc

Nếu chưa dán `linkNhanXacNhan`, trang vẫn chạy: khách bấm gửi sẽ mở sẵn tin nhắn tới **0372362558**.

## 3. Đưa lên mạng (như trang gốc)

Cách nhanh nhất — GitHub Pages:

1. Tạo repo mới, ví dụ `Bach_graduation`.
2. Upload `index.html` (và ảnh nếu có). **Không** cần upload `Code.gs` lên GitHub.
3. Settings → Pages → Deploy from branch `main` / folder `/`.
4. Link sẽ là: `https://TEN-USER.github.io/Bach_graduation/`

Gửi khách kèm tên:

`https://TEN-USER.github.io/Bach_graduation/?ten=Cô%20Lan`

## Lưu ý

- Phải deploy script bằng **đúng Google account sở hữu Sheet**.
- Sửa code script xong phải **Deploy → Manage deployments → Edit → New version**, không chỉ Save.
- Sheet đang share công khai link. Muốn chỉ mình xem data thì trong Sheet đổi quyền thành Restricted, script vẫn ghi được vì chạy với quyền của bạn.
